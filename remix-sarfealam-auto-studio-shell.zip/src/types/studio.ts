export type Language = 'en' | 'hi';

export type StudioMode = 'jarvis' | 'manual';

export type TargetEngine = 'auto' | 'capacitor' | 'godot4' | 'flutter' | 'unity';

export type VoicePersona = 'Aoede' | 'Kore' | 'Puck' | 'Charon';

export type VoicePhase = 'idle' | 'listening' | 'thinking' | 'speaking';

export type PanelId = 'none' | 'secrets' | 'code' | 'vault' | 'admin' | 'camera';

export type DisplayMode = 'expanded' | 'floating' | 'collapsed';

export type BotId = 'asset' | 'code' | 'vision' | 'github';

export type BotStatus = 'idle' | 'working' | 'ready' | 'error' | 'paused';

export interface BotState {
  id: BotId;
  label: string;
  status: BotStatus;
  progress: number;
  message: string;
  updatedAt: number;
}

export type AssetCategory =
  | 'vehicles'
  | 'characters'
  | 'weapons_gear'
  | 'village_world'
  | 'textures_pbr'
  | 'hdri_sky'
  | 'audio_sfx'
  | 'app_audio'
  | 'wikimedia_photos'
  | 'iconify_icons';

export interface StudioAssetItem {
  id: string;
  name: string;
  category: AssetCategory;
  source: string;
  url: string;
  previewUrl?: string;
  format?: string;
  license?: string;
  sizeBytes?: number;
  tags?: string[];
  selected?: boolean;
  addedAt: number;
}

export interface VirtualFile {
  path: string;
  content: string;
  language: string;
  updatedAt: number;
  generatedBy?: BotId | 'user';
  readOnly?: boolean;
}

export interface UserMemoryRule {
  id: string;
  rule: string;
  category: 'style' | 'engine' | 'asset' | 'workflow' | 'general';
  enabled: boolean;
  createdAt: number;
}

export interface StudioSecrets {
  geminiApiKey: string;
  geminiModel?: string;
  geminiLiveModel?: string;
  geminiTtsModel?: string;
  nvidiaApiKey?: string;
  nvidiaModel?: string;
  groqApiKey?: string;
  groqModel?: string;
  openRouterApiKey?: string;
  openRouterModel?: string;
  cohereApiKey?: string;
  cohereModel?: string;
  githubToken: string;
  githubOwner: string;
  githubRepo: string;
  targetRepo?: string;
  assetVaultUrl?: string;
  studioSupabaseUrl?: string;
  studioSupabaseAnonKey?: string;
  appsSupabaseUrl?: string;
  appsSupabaseAnonKey?: string;
  sketchfabToken?: string;
  freesoundKey?: string;
  customKeys?: Record<string, string>;
}

export interface StudioMessage {
  id: string;
  role: 'user' | 'jarvis' | 'system';
  text: string;
  timestamp: number;
  language?: Language;
  botRef?: BotId;
  providerUsed?: string;
  actionLabels?: string[];
}

export interface WorldState {
  projectName: string;
  language: Language;
  mode: StudioMode;
  targetEngine: TargetEngine;
  paused: boolean;
  liveActive: boolean;
  currentStage: string;
  activePanel: PanelId;
  displayMode: DisplayMode;
  voicePersona: VoicePersona;
  voiceSpeed: number;
  bots: Record<BotId, BotState>;
  selectedAssets: StudioAssetItem[];
  files: VirtualFile[];
  memoryRules: UserMemoryRule[];
  messages: StudioMessage[];
  secrets: StudioSecrets;
  lastUpdated: number;
}

export const VOICE_PERSONAS: VoicePersona[] = ['Aoede', 'Kore', 'Puck', 'Charon'];

export const VOICE_SPEEDS: number[] = [1.0, 1.15, 1.25, 1.5];

export const TARGET_ENGINES: { value: TargetEngine; label: string }[] = [
  { value: 'auto', label: 'Auto' },
  { value: 'capacitor', label: 'Capacitor' },
  { value: 'godot4', label: 'Godot 4' },
  { value: 'flutter', label: 'Flutter' },
  { value: 'unity', label: 'Unity' },
];
