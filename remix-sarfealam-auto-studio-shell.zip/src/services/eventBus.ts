import type {
  BotId,
  BotStatus,
  PanelId,
  VoicePersona,
  VoicePhase,
  WorldState,
} from '../types/studio';

export interface StudioEventMap {
  'bot:progress': {
    botId: BotId;
    status: BotStatus;
    progress: number;
    message: string;
  };
  'ui:panel': {
    panel: PanelId;
  };
  'voice:state': {
    active: boolean;
    phase?: VoicePhase;
    model?: string | null;
    persona?: VoicePersona;
    speed?: number;
    listening?: boolean;
    speaking?: boolean;
    error?: string;
  };
  'world:update': {
    patch: Partial<WorldState>;
    source?: string;
  };
}

export type StudioEventName = keyof StudioEventMap;

export type StudioEventHandler<K extends StudioEventName> = (
  payload: StudioEventMap[K]
) => void;

class TypedStudioEventBus {
  private listeners = new Map<StudioEventName, Set<(payload: unknown) => void>>();

  on<K extends StudioEventName>(
    event: K,
    handler: StudioEventHandler<K>
  ): () => void {
    let set = this.listeners.get(event);
    if (!set) {
      set = new Set<(payload: unknown) => void>();
      this.listeners.set(event, set);
    }
    set.add(handler as (payload: unknown) => void);
    return () => this.off(event, handler);
  }

  off<K extends StudioEventName>(
    event: K,
    handler: StudioEventHandler<K>
  ): void {
    const set = this.listeners.get(event);
    if (!set) return;
    set.delete(handler as (payload: unknown) => void);
    if (set.size === 0) {
      this.listeners.delete(event);
    }
  }

  emit<K extends StudioEventName>(event: K, payload: StudioEventMap[K]): void {
    const set = this.listeners.get(event);
    if (!set || set.size === 0) return;
    for (const handler of set) {
      (handler as StudioEventHandler<K>)(payload);
    }
  }
}

export const studioBus = new TypedStudioEventBus();
