import { studioBus } from './eventBus';
import { stopStudioSpeech } from './cloudTtsService';
import type { Language } from '../types/studio';

export interface DictationOptions {
  language: Language;
  onInterim?: (transcript: string) => void;
  onFinal: (transcript: string) => void;
  onError?: (message: string) => void;
  isLiveActive: boolean;
  stopLiveFirst: () => void;
}

interface SpeechRecognitionAlternativeLike {
  transcript: string;
}

interface SpeechRecognitionResultLike {
  isFinal: boolean;
  length: number;
  [index: number]: SpeechRecognitionAlternativeLike;
}

interface SpeechRecognitionResultListLike {
  length: number;
  [index: number]: SpeechRecognitionResultLike;
}

interface SpeechRecognitionEventLike {
  resultIndex: number;
  results: SpeechRecognitionResultListLike;
}

interface SpeechRecognitionErrorEventLike {
  error: string;
  message?: string;
}

interface SpeechRecognitionInstanceLike {
  lang: string;
  interimResults: boolean;
  continuous: boolean;
  maxAlternatives: number;
  onstart: (() => void) | null;
  onresult: ((event: SpeechRecognitionEventLike) => void) | null;
  onerror: ((event: SpeechRecognitionErrorEventLike) => void) | null;
  onend: (() => void) | null;
  start: () => void;
  stop: () => void;
  abort: () => void;
}

type SpeechRecognitionCtor = new () => SpeechRecognitionInstanceLike;

const ANDROID_MIC_RELEASE_DELAY_MS = 160;

let activeRecognition: SpeechRecognitionInstanceLike | null = null;
let dictatingFlag = false;
let manualStop = false;

function getSpeechRecognitionCtor(): SpeechRecognitionCtor | null {
  if (typeof window === 'undefined') return null;
  const win = window as unknown as {
    SpeechRecognition?: SpeechRecognitionCtor;
    webkitSpeechRecognition?: SpeechRecognitionCtor;
  };
  return win.SpeechRecognition ?? win.webkitSpeechRecognition ?? null;
}

function emitDictationPhase(phase: 'listening' | 'idle'): void {
  dictatingFlag = phase === 'listening';
  studioBus.emit('voice:state', {
    active: false,
    phase,
    listening: phase === 'listening',
    speaking: false,
  });
}

export function isDictating(): boolean {
  return dictatingFlag;
}

export function stopDictation(): void {
  manualStop = true;
  if (activeRecognition) {
    const instance = activeRecognition;
    activeRecognition = null;
    try {
      instance.stop();
    } catch {
      try {
        instance.abort();
      } catch {
        // ignore
      }
    }
  }
  emitDictationPhase('idle');
}

export async function startDictation(
  options: DictationOptions
): Promise<boolean> {
  // Always silence non-Live TTS before opening mic
  stopStudioSpeech();

  // Stop any existing dictation instance first
  if (activeRecognition) {
    stopDictation();
  }

  // Android Mic-Lock Sequential Guard:
  // Release getUserMedia completely (~160ms) BEFORE starting SpeechRecognition
  if (options.isLiveActive) {
    options.stopLiveFirst();
    await new Promise<void>((resolve) =>
      window.setTimeout(resolve, ANDROID_MIC_RELEASE_DELAY_MS)
    );
  }

  const RecognitionCtor = getSpeechRecognitionCtor();
  if (!RecognitionCtor) {
    const msg =
      options.language === 'hi'
        ? 'इस ब्राउज़र/WebView में Speech Recognition उपलब्ध नहीं है।'
        : 'Speech Recognition is not supported in this browser or WebView.';
    emitDictationPhase('idle');
    options.onError?.(msg);
    return false;
  }

  manualStop = false;
  const recognition = new RecognitionCtor();
  recognition.lang = options.language === 'hi' ? 'hi-IN' : 'en-US';
  recognition.interimResults = true;
  recognition.continuous = false;
  recognition.maxAlternatives = 1;

  let accumulatedFinal = '';
  let latestInterim = '';
  let deliveredFinal = false;

  activeRecognition = recognition;

  recognition.onstart = () => {
    emitDictationPhase('listening');
  };

  recognition.onresult = (event: SpeechRecognitionEventLike) => {
    let interimChunk = '';
    for (let i = event.resultIndex; i < event.results.length; i++) {
      const result = event.results[i];
      const text = result?.[0]?.transcript ?? '';
      if (!text) continue;
      if (result.isFinal) {
        accumulatedFinal = `${accumulatedFinal} ${text}`.trim();
      } else {
        interimChunk = `${interimChunk} ${text}`.trim();
      }
    }
    latestInterim = interimChunk;
    const combined = `${accumulatedFinal} ${latestInterim}`.trim();
    if (combined) {
      options.onInterim?.(combined);
    }
  };

  recognition.onerror = (event: SpeechRecognitionErrorEventLike) => {
    const code = event.error || 'unknown';
    if (activeRecognition === recognition) {
      activeRecognition = null;
    }
    emitDictationPhase('idle');

    if (manualStop || code === 'aborted') return;

    const friendly =
      code === 'not-allowed' || code === 'service-not-allowed'
        ? options.language === 'hi'
          ? 'माइक्रोफ़ोन अनुमति अस्वीकृत हुई।'
          : 'Microphone permission denied for dictation.'
        : code === 'no-speech'
          ? options.language === 'hi'
            ? 'कोई आवाज़ सुनाई नहीं दी — दोबारा टैप करके बोलें।'
            : 'No speech detected — tap the mic and try again.'
          : `Dictation error: ${code}`;

    options.onError?.(friendly);
  };

  recognition.onend = () => {
    if (activeRecognition === recognition) {
      activeRecognition = null;
    }
    emitDictationPhase('idle');

    if (!deliveredFinal) {
      deliveredFinal = true;
      const finalTranscript = (accumulatedFinal || latestInterim).trim();
      if (finalTranscript) {
        options.onFinal(finalTranscript);
      }
    }
  };

  try {
    recognition.start();
    emitDictationPhase('listening');
    return true;
  } catch (err) {
    if (activeRecognition === recognition) {
      activeRecognition = null;
    }
    emitDictationPhase('idle');
    const msg =
      err instanceof Error ? err.message : 'Unable to start speech recognition.';
    options.onError?.(msg);
    return false;
  }
}
