import { useState, type FormEvent } from 'react';
import {
  Brain,
  Plus,
  Trash2,
  X,
  RefreshCw,
  CheckCircle2,
  AlertCircle,
  Loader2,
} from 'lucide-react';
import type { Language, StudioSecrets, UserMemoryRule } from '../types/studio';
import {
  syncMemoryWithSupabase,
  type MemorySyncResult,
} from '../services/memoryService';

interface MemoryRulesModalProps {
  open: boolean;
  rules: UserMemoryRule[];
  secrets: StudioSecrets;
  language: Language;
  onAddRule: (ruleText: string, category?: UserMemoryRule['category']) => void;
  onToggleRule: (id: string) => void;
  onDeleteRule: (id: string) => void;
  onSyncComplete: (syncedRules: UserMemoryRule[]) => void;
  onClose: () => void;
}

const CATEGORIES: { value: UserMemoryRule['category']; label: string }[] = [
  { value: 'general', label: 'General' },
  { value: 'style', label: 'Style' },
  { value: 'engine', label: 'Engine' },
  { value: 'asset', label: 'Asset' },
  { value: 'workflow', label: 'Workflow' },
];

function getCategoryStyle(category: UserMemoryRule['category']): string {
  switch (category) {
    case 'style':
      return 'bg-[#5856D6]/10 text-[#5856D6]';
    case 'engine':
      return 'bg-[#007AFF]/10 text-[#007AFF]';
    case 'asset':
      return 'bg-[#10B981]/12 text-[#047857]';
    case 'workflow':
      return 'bg-[#F59E0B]/14 text-[#B45309]';
    default:
      return 'bg-slate-100 text-[#475569]';
  }
}

export function MemoryRulesModal({
  open,
  rules,
  secrets,
  language,
  onAddRule,
  onToggleRule,
  onDeleteRule,
  onSyncComplete,
  onClose,
}: MemoryRulesModalProps) {
  const [newRuleText, setNewRuleText] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<
    UserMemoryRule['category'] | 'auto'
  >('auto');
  const [syncing, setSyncing] = useState(false);
  const [syncStatus, setSyncStatus] = useState<MemorySyncResult | null>(null);

  if (!open) return null;

  const activeCount = rules.filter((r) => r.enabled).length;

  const handleSubmit = (e: FormEvent) => {
    e.preventDefault();
    const cleaned = newRuleText.trim();
    if (cleaned.length < 3) return;
    onAddRule(
      cleaned,
      selectedCategory === 'auto' ? undefined : selectedCategory
    );
    setNewRuleText('');
    setSyncStatus(null);
  };

  const handleSync = async () => {
    setSyncing(true);
    setSyncStatus(null);
    const result = await syncMemoryWithSupabase(secrets, rules);
    setSyncStatus(result);
    if (result.ok) {
      onSyncComplete(result.rules);
    }
    setSyncing(false);
  };

  return (
    <div
      className="fixed inset-0 z-50 bg-slate-900/25 backdrop-blur-[3px] flex items-end sm:items-center justify-center sm:p-4"
      onClick={onClose}
      role="dialog"
      aria-modal="true"
      aria-label="Permanent Memory and Rules"
    >
      <div
        onClick={(e) => e.stopPropagation()}
        className="w-full max-w-full sm:max-w-lg mx-auto bg-[#F8FAFE]/95 backdrop-blur-2xl border-t sm:border border-slate-200/90 rounded-t-3xl sm:rounded-3xl shadow-[0_-14px_48px_rgba(15,23,42,0.18)] flex flex-col max-h-[88dvh] sm:max-h-[84dvh] overflow-hidden"
      >
        {/* Drag Handle (mobile) */}
        <div className="pt-2.5 pb-1 flex justify-center sm:hidden shrink-0">
          <div className="w-10 h-1 rounded-full bg-slate-300/90" aria-hidden="true" />
        </div>

        {/* Sticky Sheet Header */}
        <div className="px-3.5 sm:px-5 py-2.5 bg-white/85 backdrop-blur-xl border-b border-slate-200/80 flex items-center justify-between gap-2 shrink-0">
          <div className="flex items-center gap-2.5 min-w-0">
            <div
              className="w-8 h-8 rounded-xl bg-gradient-to-br from-[#F59E0B] to-[#5856D6] text-white flex items-center justify-center shadow-xs shrink-0"
              aria-hidden="true"
            >
              <Brain className="w-4 h-4" />
            </div>
            <div className="min-w-0">
              <h2 className="text-[14px] sm:text-[15px] font-bold text-[#0F172A] tracking-tight truncate">
                Permanent Memory &amp; Rules
              </h2>
              <p className="text-[11px] font-medium text-[#64748B] truncate tabular-nums">
                {activeCount} active · {rules.length} saved · Injected into AI &amp; Live Voice
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            aria-label="Close Permanent Memory and Rules"
            className="w-9 h-9 rounded-full bg-slate-100 hover:bg-slate-200/80 text-[#0F172A] flex items-center justify-center transition-colors shrink-0 cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Add New Rule Form */}
        <form
          onSubmit={handleSubmit}
          className="px-3.5 sm:px-5 py-3 bg-white/75 border-b border-slate-200/75 flex flex-col gap-2 shrink-0"
        >
          <div className="flex items-center gap-1.5">
            <label htmlFor="memory-new-rule-input" className="sr-only">
              New permanent rule
            </label>
            <input
              id="memory-new-rule-input"
              type="text"
              value={newRuleText}
              onChange={(e) => setNewRuleText(e.target.value)}
              placeholder={
                language === 'hi'
                  ? 'नया नियम लिखें (उदा. हमेशा हिंदी में जवाब दो...)'
                  : 'Add a permanent rule (e.g. Always keep UI compact)...'
              }
              className="flex-1 min-w-0 h-10 px-3 rounded-xl bg-white border border-slate-200/90 text-[12.5px] text-[#0F172A] placeholder:text-[#94A3B8] focus:outline-none focus:border-[#007AFF] focus:ring-2 focus:ring-[#007AFF]/15"
            />
            <button
              type="submit"
              disabled={newRuleText.trim().length < 3}
              className="h-10 px-3 rounded-xl bg-gradient-to-r from-[#007AFF] to-[#5856D6] hover:brightness-105 disabled:opacity-45 text-white text-[12px] font-semibold inline-flex items-center gap-1 shadow-xs transition-all whitespace-nowrap shrink-0 cursor-pointer active:scale-[0.98]"
            >
              <Plus className="w-3.5 h-3.5 shrink-0" aria-hidden="true" />
              <span>Save Rule</span>
            </button>
          </div>

          <div className="flex items-center gap-1 flex-wrap">
            <button
              type="button"
              onClick={() => setSelectedCategory('auto')}
              className={`px-2 py-0.5 rounded-md text-[10.5px] font-semibold transition-all cursor-pointer ${
                selectedCategory === 'auto'
                  ? 'bg-[#0F172A] text-white'
                  : 'bg-slate-100 text-[#64748B] hover:text-[#0F172A]'
              }`}
            >
              Auto
            </button>
            {CATEGORIES.map((cat) => (
              <button
                key={cat.value}
                type="button"
                onClick={() => setSelectedCategory(cat.value)}
                className={`px-2 py-0.5 rounded-md text-[10.5px] font-semibold transition-all cursor-pointer ${
                  selectedCategory === cat.value
                    ? 'bg-[#5856D6] text-white'
                    : 'bg-slate-100 text-[#64748B] hover:text-[#0F172A]'
                }`}
              >
                {cat.label}
              </button>
            ))}
          </div>
        </form>

        {/* Scrollable Rules List */}
        <div className="flex-1 min-h-0 overflow-y-auto studio-scroll px-3.5 sm:px-5 py-3 flex flex-col gap-2">
          {rules.length === 0 ? (
            <div className="rounded-2xl bg-white/85 border border-dashed border-slate-300/90 p-5 text-center flex flex-col items-center gap-1.5">
              <Brain className="w-6 h-6 text-[#F59E0B]" aria-hidden="true" />
              <p className="text-[12.5px] font-bold text-[#0F172A]">
                {language === 'hi'
                  ? 'अभी कोई स्थायी नियम सेव नहीं है'
                  : 'No Permanent Rules Saved Yet'}
              </p>
              <p className="text-[11.5px] text-[#64748B] max-w-xs leading-relaxed">
                {language === 'hi'
                  ? 'ऊपर नियम जोड़ें या चैट/वॉइस में "याद रखना..." या "Remember that..." बोलें।'
                  : 'Add a rule above, or say "Remember that...", "Always...", or "Yaad rakhna..." in chat or voice.'}
              </p>
            </div>
          ) : (
            rules.map((item) => (
              <div
                key={item.id}
                className={`rounded-2xl bg-white/90 border p-2.5 flex items-start justify-between gap-2.5 transition-all ${
                  item.enabled
                    ? 'border-slate-200/85 shadow-[0_3px_12px_rgba(15,23,42,0.04)]'
                    : 'border-slate-200/60 opacity-65'
                }`}
              >
                {/* Active Toggle Switch */}
                <button
                  type="button"
                  role="switch"
                  aria-checked={item.enabled}
                  aria-label={item.enabled ? 'Disable rule' : 'Enable rule'}
                  onClick={() => onToggleRule(item.id)}
                  className={`mt-0.5 w-9 h-5 rounded-full p-0.5 transition-colors shrink-0 cursor-pointer flex items-center ${
                    item.enabled ? 'bg-[#10B981]' : 'bg-slate-300'
                  }`}
                >
                  <span
                    className={`w-4 h-4 rounded-full bg-white shadow-xs transition-transform ${
                      item.enabled ? 'translate-x-4' : 'translate-x-0'
                    }`}
                  />
                </button>

                {/* Rule Content & Category */}
                <div className="min-w-0 flex-1">
                  <p
                    className={`text-[12.5px] leading-snug break-words ${
                      item.enabled
                        ? 'font-medium text-[#0F172A]'
                        : 'line-through text-[#64748B]'
                    }`}
                  >
                    {item.rule}
                  </p>
                  <div className="mt-1 flex items-center gap-1.5">
                    <span
                      className={`px-1.5 py-0.5 rounded-md text-[10px] font-semibold capitalize ${getCategoryStyle(
                        item.category
                      )}`}
                    >
                      {item.category}
                    </span>
                    <span className="text-[10px] text-[#64748B]">
                      {item.enabled ? 'Active' : 'Disabled'}
                    </span>
                  </div>
                </div>

                {/* Delete Rule Button */}
                <button
                  type="button"
                  onClick={() => onDeleteRule(item.id)}
                  aria-label={`Delete rule: ${item.rule}`}
                  className="w-8 h-8 rounded-lg text-[#64748B] hover:text-[#FF3B30] hover:bg-[#FF3B30]/10 flex items-center justify-center transition-colors shrink-0 cursor-pointer"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
            ))
          )}
        </div>

        {/* Sticky Footer: Studio Supabase Sync + Status Feedback */}
        <div className="px-3.5 sm:px-5 py-3 bg-white/92 backdrop-blur-xl border-t border-slate-200/80 flex flex-col gap-2 shrink-0 pb-[max(0.75rem,env(safe-area-inset-bottom))]">
          {syncStatus && (
            <div
              className={`px-3 py-1.5 rounded-xl text-[11px] font-semibold flex items-center gap-1.5 ${
                syncStatus.ok
                  ? 'bg-[#10B981]/12 text-[#047857]'
                  : 'bg-[#F59E0B]/14 text-[#B45309]'
              }`}
            >
              {syncStatus.ok ? (
                <CheckCircle2 className="w-3.5 h-3.5 shrink-0" aria-hidden="true" />
              ) : (
                <AlertCircle className="w-3.5 h-3.5 shrink-0" aria-hidden="true" />
              )}
              <span className="break-words">{syncStatus.message}</span>
            </div>
          )}

          <button
            type="button"
            onClick={handleSync}
            disabled={syncing}
            className="w-full h-10 rounded-xl bg-gradient-to-r from-[#5856D6] to-[#007AFF] hover:brightness-105 disabled:opacity-60 text-white text-[12.5px] font-bold inline-flex items-center justify-center gap-1.5 shadow-[0_4px_14px_rgba(88,86,214,0.25)] transition-all cursor-pointer active:scale-[0.98]"
          >
            {syncing ? (
              <Loader2 className="w-4 h-4 animate-spin shrink-0" aria-hidden="true" />
            ) : (
              <RefreshCw className="w-3.5 h-3.5 shrink-0" aria-hidden="true" />
            )}
            <span>{syncing ? 'Syncing Studio Supabase...' : 'Sync Supabase'}</span>
          </button>
        </div>
      </div>
    </div>
  );
}
