import { Layers, ChevronDown } from 'lucide-react';
import {
  TARGET_ENGINES,
  type Language,
  type StudioMode,
  type TargetEngine,
} from '../types/studio';

interface TopBarProps {
  language: Language;
  mode: StudioMode;
  targetEngine: TargetEngine;
  onLanguageChange: (language: Language) => void;
  onModeChange: (mode: StudioMode) => void;
  onEngineChange: (engine: TargetEngine) => void;
}

export function TopBar({
  language,
  mode,
  targetEngine,
  onLanguageChange,
  onModeChange,
  onEngineChange,
}: TopBarProps) {
  return (
    <header className="sticky top-0 z-30 w-full bg-white/85 backdrop-blur-xl border-b border-slate-200/80 shadow-[0_4px_24px_rgba(15,23,42,0.04)]">
      <div className="max-w-5xl mx-auto px-2.5 sm:px-5 py-2">
        <div className="grid grid-cols-[minmax(0,1fr)_auto] sm:flex sm:items-center sm:justify-between gap-x-2 gap-y-1.5">
          {/* App Brand */}
          <div className="flex items-center gap-2 min-w-0">
            <div
              className="w-7 h-7 rounded-[9px] bg-gradient-to-br from-[#007AFF] via-[#5856D6] to-[#10B981] text-white flex items-center justify-center shadow-[0_3px_10px_rgba(0,122,255,0.28)] shrink-0"
              aria-hidden="true"
            >
              <Layers className="w-4 h-4 stroke-[2.25]" />
            </div>
            <h1 className="text-[13.5px] sm:text-[15px] font-bold tracking-tight text-[#0F172A] truncate whitespace-nowrap">
              Sarfealam Auto-Studio
            </h1>
          </div>

          {/* Language Segmented Pill: EN | हिं */}
          <div
            className="inline-flex items-center p-0.5 rounded-full bg-slate-100/95 border border-slate-200/80 shrink-0 sm:order-2"
            role="group"
            aria-label="Language"
          >
            <button
              type="button"
              onClick={() => onLanguageChange('en')}
              aria-pressed={language === 'en'}
              className={`px-2.5 h-7 rounded-full text-[11px] font-semibold transition-all whitespace-nowrap shrink-0 cursor-pointer ${
                language === 'en'
                  ? 'bg-[#007AFF] text-white shadow-xs'
                  : 'text-[#64748B] hover:text-[#0F172A]'
              }`}
            >
              EN
            </button>
            <button
              type="button"
              onClick={() => onLanguageChange('hi')}
              aria-pressed={language === 'hi'}
              className={`px-2.5 h-7 rounded-full text-[11px] font-semibold transition-all whitespace-nowrap shrink-0 cursor-pointer ${
                language === 'hi'
                  ? 'bg-[#007AFF] text-white shadow-xs'
                  : 'text-[#64748B] hover:text-[#0F172A]'
              }`}
            >
              हिं
            </button>
          </div>

          {/* Mode Segmented Pill + Engine Selector */}
          <div className="col-span-2 flex items-center justify-between sm:justify-end gap-1.5 sm:gap-2 min-w-0 sm:order-3">
            {/* JARVIS | Manual Segmented Pill */}
            <div
              className="inline-flex items-center p-0.5 rounded-full bg-slate-100/95 border border-slate-200/80 shrink-0"
              role="group"
              aria-label="Studio Mode"
            >
              <button
                type="button"
                onClick={() => onModeChange('jarvis')}
                aria-pressed={mode === 'jarvis'}
                className={`px-2.5 h-7 rounded-full text-[11px] font-semibold transition-all whitespace-nowrap shrink-0 cursor-pointer ${
                  mode === 'jarvis'
                    ? 'bg-gradient-to-r from-[#007AFF] to-[#5856D6] text-white shadow-xs'
                    : 'text-[#64748B] hover:text-[#0F172A]'
                }`}
              >
                JARVIS
              </button>
              <button
                type="button"
                onClick={() => onModeChange('manual')}
                aria-pressed={mode === 'manual'}
                className={`px-2.5 h-7 rounded-full text-[11px] font-semibold transition-all whitespace-nowrap shrink-0 cursor-pointer ${
                  mode === 'manual'
                    ? 'bg-[#0F172A] text-white shadow-xs'
                    : 'text-[#64748B] hover:text-[#0F172A]'
                }`}
              >
                Manual
              </button>
            </div>

            {/* Engine Selector */}
            <div className="relative flex items-center min-w-0 shrink-0">
              <label htmlFor="studio-engine-select" className="sr-only">
                Target Engine
              </label>
              <select
                id="studio-engine-select"
                value={targetEngine}
                onChange={(e) => onEngineChange(e.target.value as TargetEngine)}
                className="appearance-none h-8 pl-2.5 pr-7 rounded-full bg-white/95 border border-slate-200/90 text-[11.5px] font-semibold text-[#0F172A] shadow-xs focus:outline-none focus:border-[#007AFF] focus:ring-2 focus:ring-[#007AFF]/15 cursor-pointer"
              >
                {TARGET_ENGINES.map((engine) => (
                  <option key={engine.value} value={engine.value}>
                    Engine: {engine.label}
                  </option>
                ))}
              </select>
              <ChevronDown
                className="w-3.5 h-3.5 text-[#64748B] pointer-events-none absolute right-2.5"
                aria-hidden="true"
              />
            </div>
          </div>
        </div>
      </div>
    </header>
  );
}
